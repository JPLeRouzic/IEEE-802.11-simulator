package zzInfra.layer1;

import java.util.List;

public interface JE802TraceParser {

	List<JE802LocationInfo> parseFile();

}
