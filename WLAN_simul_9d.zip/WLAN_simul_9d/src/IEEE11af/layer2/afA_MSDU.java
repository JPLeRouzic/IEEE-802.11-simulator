/*
afA_MSDU
*/
/*
 * 
 */
package IEEE11af.layer2;

/**
 * @author jean-Pierre Le Rouzic
 */
public class afA_MSDU {

}
 
