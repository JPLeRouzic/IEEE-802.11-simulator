/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package IEEE11ac.layer1;

/**
 * @author jean-Pierre Le Rouzic
 */
public class acTX_VECTOR {

}
