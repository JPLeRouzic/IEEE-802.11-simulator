/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package IEEE11ac.layer2;

/**
 * @author jean-Pierre Le Rouzic
 */
public class acBlock_Ack {

}
