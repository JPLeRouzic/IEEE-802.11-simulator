/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package IEEE11ac.layer2;

/**
 * @author jean-Pierre Le Rouzic
 */
public class acRTS_CTS {
    //Transmission with RTS/CTS


    //Transmission with CTS-to-Self


    //Transmission with basic access


    private void receiveRts() {

    }

    private void receiveAck() {

    }

    private void receiveCts() {

    }

    private void retryRts() {

    }

    //Transmission with CTS-to-Self


    //Transmission with basic access

    private void generateRts() {

    }

    private void generateCts() {

    }

    private void generateCtstoSelf() {

    }

    private void generateAck() {

    }


}
