/*
acA_MSDU
*/
/*
 * 
 */
package IEEE11ac.layer2;

/**
 * @author jean-Pierre Le Rouzic
 */
public class acA_MSDU {

}
 
