%=============================================================================================================================
% Result "thrp_SA11_DA1_AC2_ID_333_saturation_fixed__End". Sat May 31 18:11:44 CEST 2014.
%-----------------------------------------------------------------------------------------------------------------------------
% time[ms] | #packets | overall #packets | avrg.packetsize[byte] | overall sum packetsize[byte] | thpt overall[Mb/s] | tpht last interval[Mb/s]
%=============================================================================================================================
result_thrp_SA11_DA1_AC2_ID_333_saturation_fixed__End = [
0.0	0	0	NaN	0.0	NaN	NaN
100.0	0	0	NaN	0.0	0.0	NaN
200.0	0	0	NaN	0.0	0.0	NaN
300.0	0	0	NaN	0.0	0.0	NaN
400.0	0	0	NaN	0.0	0.0	NaN
500.0	0	0	NaN	0.0	0.0	NaN
600.0	0	0	NaN	0.0	0.0	NaN
700.0	0	0	NaN	0.0	0.0	NaN
800.0	0	0	NaN	0.0	0.0	NaN
900.0	0	0	NaN	0.0	0.0	NaN
]; % Sat May 31 18:12:07 CEST 2014
